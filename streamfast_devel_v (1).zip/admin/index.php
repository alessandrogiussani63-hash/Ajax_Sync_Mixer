<?php
// Simple admin landing (protect with .htaccess or reverse proxy auth)
?>
<h1>StreamFast Admin</h1>
<ul>
  <li><a href="add_channel.php">Add Channel</a></li>
  <li><a href="upload.php">Upload Media</a></li>
  <li><a href="../consol.php">Open Console</a></li>
  <li><a href="../smoke_test.html">Smoke Test</a></li>
</ul>
<p>Remember to protect /admin and write_synk.php with authentication.</p>
