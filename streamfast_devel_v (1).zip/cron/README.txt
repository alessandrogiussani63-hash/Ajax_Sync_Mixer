# Cron setup (example)
* * * * * /usr/bin/php /path/to/cron/scheduler.php >> /var/log/streamfast-scheduler.log 2>&1
